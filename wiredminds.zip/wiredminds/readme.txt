Description:
This plugin integrates the WiredMinds pixelcode in WordPress.

Installation:
1. You must have an active WiredMinds account in order to use the plugin.
2. Upload the "wiredminds" folder to the "/wp-content/plugins/" directory.
3. Activate the plugin at the 'Plugins' section in WordPress.
4. Enter the customer number at "Settings/WiredMinds"